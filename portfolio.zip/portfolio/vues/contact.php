<?php include '../config.php'; ?>
<?php $css_path = '../assets/css/style.css'; ?>

<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h2>Contact</h2>
    <p>Une question, une opportunité de stage ?</p>
</div>

<div class="contact-info" style="max-width: 420px; padding-bottom: 4rem;">

    <div class="contact-info-item">
        <div class="contact-icon">✉️</div>
        <div>
            <div class="contact-info-label">Email</div>
            <div class="contact-info-val">
                <a href="mailto:<?php echo $email; ?>" style="color: var(--text); text-decoration: none;">
                    <?php echo $email; ?>
                </a>
            </div>
        </div>
    </div>

    <div class="contact-info-item">
        <div class="contact-icon">🎓</div>
        <div>
            <div class="contact-info-label">Formation</div>
            <div class="contact-info-val">BTS SIO — Promo <?php echo $promo; ?></div>
        </div>
    </div>

</div>

<?php include '../includes/footer.php'; ?>

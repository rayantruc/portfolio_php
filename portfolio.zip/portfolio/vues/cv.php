<?php include '../config.php'; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h2>Mon CV</h2>
    <p>Compétences, formation et expériences</p>
</div>

<div class="cv-grid">

    <div class="card">
        <div class="cv-section-title">Compétences</div>
        <?php foreach ($competences as $comp): ?>
            <span class="skill-tag">
                <span class="skill-dot"></span>
                <?php echo htmlspecialchars($comp); ?>
            </span>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <div class="cv-section-title">À propos</div>
        <p style="color: var(--muted); font-size: 0.95rem; line-height: 1.7; margin-bottom: 1.25rem;">
            Étudiant en <strong style="color: var(--text)">BTS SIO</strong> option SISR/SLAM, 
            je développe des compétences en administration réseau, développement web et gestion de serveurs.
        </p>
        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
            <div style="display: flex; gap: 10px; font-size: 0.9rem;">
                <span style="color: var(--muted)">Formation</span>
                <span>BTS SIO — Promo <?php echo $promo; ?></span>
            </div>
            <div style="display: flex; gap: 10px; font-size: 0.9rem;">
                <span style="color: var(--muted)">Projets</span>
                <span><?php echo count($projets); ?> réalisés</span>
            </div>
            <div style="display: flex; gap: 10px; font-size: 0.9rem;">
                <span style="color: var(--muted)">Contact</span>
                <a href="mailto:<?php echo $email; ?>" style="color: var(--text); text-decoration: none;"><?php echo $email; ?></a>
            </div>
        </div>
    </div>

    <div class="cv-pdf-wrap">
        <div class="cv-pdf-header">
            <span>CV — <?php echo $nom; ?></span>
            <a href="/portfolio/vues/cv.pdf" download class="btn-ghost" style="font-size:0.8rem; padding: 6px 14px;">
                Télécharger ↓
            </a>
        </div>
        <div class="cv-pdf-body">
            <iframe src="/portfolio/vues/cv.pdf" title="CV de <?php echo $nom; ?>">
                <p style="padding:2rem; color:#333;">
                    Votre navigateur ne supporte pas l'affichage PDF. 
                    <a href="/portfolio/vues/cv.pdf">Téléchargez-le ici</a>.
                </p>
            </iframe>
        </div>
    </div>

</div>

<?php include '../includes/footer.php'; ?>

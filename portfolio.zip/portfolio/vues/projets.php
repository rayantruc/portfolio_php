<?php include '../config.php'; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h2>Mes Projets</h2>
    <p><?php echo count($projets); ?> projets réalisés durant ma formation BTS SIO</p>
</div>

<div class="projets-grid">

<?php foreach ($projets as $projet): ?>
    <div class="card projet-card">
        <div class="projet-card-top">
            <h3 class="projet-title"><?php echo htmlspecialchars($projet['titre']); ?></h3>
            <?php if ($projet['statut'] === 'validé'): ?>
                <span class="badge badge-valide">Validé</span>
            <?php else: ?>
                <span class="badge badge-encours">En cours</span>
            <?php endif; ?>
        </div>
        <p class="projet-desc"><?php echo htmlspecialchars($projet['desc']); ?></p>
        <span class="projet-tech"><?php echo htmlspecialchars($projet['tech']); ?></span>
    </div>
<?php endforeach; ?>

</div>

<?php include '../includes/footer.php'; ?>

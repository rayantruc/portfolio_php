<?php include '../config.php'; ?>
<?php include '../includes/header.php'; ?>

<div class="page-header">
    <h2>Veille technologique</h2>
    <p>Évolutions du secteur IT suivies durant ma formation</p>
</div>

<div class="veille-list">

<?php foreach ($veille as $article): ?>
    <div class="veille-item">
        <div class="veille-meta">
            <span class="veille-categorie"><?php echo htmlspecialchars($article['categorie']); ?></span>
            <span class="veille-date"><?php echo htmlspecialchars($article['date']); ?></span>
        </div>
        <h3 class="veille-titre"><?php echo htmlspecialchars($article['titre']); ?></h3>
        <p class="veille-resume"><?php echo htmlspecialchars($article['resume']); ?></p>
        <a href="<?php echo $article['url']; ?>" target="_blank" class="veille-source">
            <?php echo htmlspecialchars($article['source']); ?> ↗
        </a>
    </div>
<?php endforeach; ?>

</div>

<?php include '../includes/footer.php'; ?>

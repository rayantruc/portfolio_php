<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $nom; ?> — Portfolio</title>
    <link rel="stylesheet" href="/portfolio/assets/css/style.css">
</head>
<body>

<header>
    <a href="/portfolio/index.php" class="logo">
        <span class="logo-dot"></span>
        <?php echo $nom; ?>
    </a>
    <nav>
        <a href="/portfolio/index.php">Accueil</a>
        <a href="/portfolio/vues/cv.php">CV</a>
        <a href="/portfolio/vues/projets.php">Projets</a>
        <a href="/portfolio/vues/veille.php">Veille</a>
        <a href="/portfolio/vues/contact.php">Contact</a>
    </nav>
</header>

<main>

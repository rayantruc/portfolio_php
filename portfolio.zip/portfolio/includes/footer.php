</main>

<footer>
    <p>&copy; <?php echo $nom; ?> — <?php echo date('Y'); ?> &nbsp;·&nbsp;
    BTS SIO Promo <?php echo $promo; ?> &nbsp;·&nbsp;
    <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></p>
</footer>

</body>
</html>
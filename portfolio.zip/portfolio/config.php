<?php 
$nom = 'Rayan Boina Boina'; 
$email = 'contact@portfolio.fr'; 
$promo = 2026;
$competences = ['HTML/CSS', 'PHP', 'XAMPP', 'SISR/SLAM', 'Bootstrap', 'Git', 'MySQL', 'Linux'];
$projets = [
    ['titre' => 'Newsletter HTML & CSS', 'desc' => 'Création d\'une newsletter responsive en HTML/CSS pur.', 'statut' => 'validé', 'tech' => 'HTML/CSS'],
    ['titre' => 'StartUp Bootstrap', 'desc' => 'Landing page pour une startup fictive avec Bootstrap 5.', 'statut' => 'validé', 'tech' => 'Bootstrap'],
    ['titre' => 'Portfolio PHP Dynamique', 'desc' => 'Ce portfolio ! Développé avec PHP, includes et variables dynamiques.', 'statut' => 'en cours', 'tech' => 'PHP'],
    ['titre' => 'Config Serveur XAMPP', 'desc' => 'Déploiement et configuration d\'un serveur XAMPP partagé en réseau local.', 'statut' => 'validé', 'tech' => 'SISR'],
];
$veille = [
    [
        'titre' => 'L\'essor des LLM open source',
        'date' => 'Mars 2025',
        'categorie' => 'Intelligence Artificielle',
        'resume' => 'Des modèles comme Mistral ou LLaMA permettent désormais de déployer des IA localement, sans dépendre de services cloud. Un tournant pour la confidentialité et l\'autonomie des entreprises.',
        'source' => 'LeMagIT',
        'url' => 'https://www.lemagit.fr',
    ],
    [
        'titre' => 'Kubernetes simplifié avec K3s',
        'date' => 'Fév. 2025',
        'categorie' => 'Infrastructure',
        'resume' => 'K3s est une distribution légère de Kubernetes pensée pour les environnements limités en ressources. Elle facilite l\'orchestration de conteneurs sur des machines peu puissantes ou en edge computing.',
        'source' => 'Dev.to',
        'url' => 'https://dev.to',
    ],
    [
        'titre' => 'Zero Trust : au-delà du VPN',
        'date' => 'Jan. 2025',
        'categorie' => 'Cybersécurité',
        'resume' => 'Le modèle Zero Trust repose sur le principe "ne jamais faire confiance, toujours vérifier". Face à l\'explosion du télétravail, il s\'impose comme alternative aux architectures réseau traditionnelles basées sur le périmètre.',
        'source' => 'ANSSI',
        'url' => 'https://www.ssi.gouv.fr',
    ],
    [
        'titre' => 'PHP 8.3 : les nouveautés',
        'date' => 'Déc. 2024',
        'categorie' => 'Développement Web',
        'resume' => 'PHP 8.3 apporte des constantes typées dans les classes, des améliorations sur json_validate() et une meilleure gestion des exceptions. Des évolutions qui renforcent la robustesse du langage.',
        'source' => 'PHP.net',
        'url' => 'https://www.php.net/releases/8.3',
    ],
];
?>

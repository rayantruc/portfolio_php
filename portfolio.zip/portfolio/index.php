<?php include 'config.php'; ?>
<?php include 'includes/header.php'; ?>

<section class="hero">
    <div class="hero-bg"></div>
    <div class="hero-content">
        <div class="hero-tag">
            <span class="logo-dot"></span>
            BTS SIO · Promo <?php echo $promo; ?>
        </div>

        <h2>
            Salut, je suis<br>
            <span><?php echo $nom; ?></span>
        </h2>

        <p class="hero-desc">
            Étudiant en BTS SIO, passionné par le développement web et les infrastructures réseau.
            Bienvenue sur mon portfolio dynamique construit en PHP.
        </p>

        <p class="hero-time">
            Il est actuellement <span class="time-val"><?php echo date('H:i'); ?></span>
            — <?php
                $h = (int)date('H');
                if ($h < 6)       echo 'bonne nuit ';
                elseif ($h < 12)  echo 'bonjour ';
                elseif ($h < 18)  echo 'bonne après-midi ';
                else              echo 'bonsoir ';
            ?>
        </p>

        <br><br>

        <div class="hero-actions">
            <a href="/portfolio/vues/cv.php" class="btn-primary">Voir mon CV →</a>
            <a href="/portfolio/vues/projets.php" class="btn-ghost">Mes projets</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>